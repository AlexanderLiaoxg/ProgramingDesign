package NET;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.JOptionPane;

import NewMusic.AccountCheck;
import Part.SongDown;
import Part.TransferInformation;

public class PlayerClient {
	private Boolean is_connect = false;
	private static TransferInformation information;
	private static CommandToSevers doit;
	public PlayerClient(CommandToSevers doit, TransferInformation information) throws Exception {
		this.doit = doit;
		this.information = information;
		
		CreateSocket();
	    
	}
	public static void CreateSocket() throws Exception {
		Socket socket = new Socket("127.0.0.1", 9998); // ��127.0.0.1���ҵ���������ͨ��ָ���˿�

		/** ������Ϣ **/
		OutputStream os = socket.getOutputStream();
		DataOutputStream dos = new DataOutputStream(os); 
		
		/** ��ȡ��Ϣ **/
		InputStream is = socket.getInputStream();
		DataInputStream dis = new DataInputStream(is);
		DeadRound cheak = new DeadRound(doit, dos, dis, information,socket);
		cheak.start();
	}
}


class DeadRound extends Thread{

	private CommandToSevers doit;
	private DataOutputStream dos;
	private DataInputStream dis;
	private TransferInformation information;
	private Socket socket;

	public DeadRound(CommandToSevers doit,DataOutputStream dos, DataInputStream dis,TransferInformation information, Socket socket) {
		this.doit =doit;
		this.dos = dos;
		this.dis = dis;
		this.information = information;
		this.socket = socket;
	}
	
	public void run() {
		while(true) {
			try {
				Thread.sleep(40);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		switch(doit.command){
		case 0 : break;
		case 1 : AccountCheck check = new AccountCheck(dos,dis,information,socket);doit.command=0;try {
				new PlayerClient(doit, information);break;
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		case 2 : try {
				SongDown down = new SongDown(dos,dis,doit.DownName,information);socket.close();doit.command=0;new PlayerClient(doit, information);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}break;
		default : JOptionPane.showMessageDialog(null, "��������ȡ��Ϣ������");
		}
		}
	}
}
