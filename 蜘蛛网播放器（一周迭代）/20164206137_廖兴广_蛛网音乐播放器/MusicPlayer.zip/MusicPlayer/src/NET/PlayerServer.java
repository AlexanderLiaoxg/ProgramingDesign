package NET;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import NewMusic.JDBC;

public class PlayerServer {
	private int command;
	private String account;
	private String passwords;
	private boolean is_close;
	private DataOutputStream dos;
	private DataInputStream dis;

	public static void main(String[] args) throws Exception {
		new PlayerServer();
	}

	public PlayerServer() throws Exception {
		ServerSocket server = new ServerSocket(9998);
		System.out.println("����������!");
		while (true) {
			Socket client = server.accept();
			System.out.print("���ӳɹ���");

			/** ������Ϣ **/
			OutputStream os = client.getOutputStream();
			dos = new DataOutputStream(os);

			/** ��ȡ��Ϣ **/
			InputStream is = client.getInputStream();
			dis = new DataInputStream(is);
            Deal d = new Deal(dis, dos,client);
            d.start();
		}
	}

}

class Deal extends Thread {
	private int command;
	private String account;
	private String passwords;
	private boolean is_close;
	private DataInputStream dis;
	private DataOutputStream dos;
	private String ToFindSong;
	private Socket client;

	public Deal(DataInputStream dis, DataOutputStream dos, Socket client) {
		super();
		this.dis = dis;
		this.dos = dos;
		this.client = client;
	}

	public void run() {
		while (true) {
			String fromClient;
			try {
				fromClient = dis.readUTF();
				System.out.println(fromClient + "����fromClient");
				if (fromClient.length() > 1) {
					analyz(fromClient);// ����Client
					client.close();
				} else if (fromClient.equals("2")) {
					ToFindSong = dis.readUTF();
					File sf = new File("C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\֩�벥�ŷ��������\\" + ToFindSong + ".wav");
					try {
						TransFile(sf, dos);
						client.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}  catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("waiting...");
				//e.printStackTrace();
			}

		}
	}

	private void analyz(String fromClient) throws Exception {
		// TODO Auto-generated method stub
		String pat = "\\s"; // ��ַ�
		Pattern pattern = Pattern.compile(pat);// ��֤��
		String[] commands = pattern.split(fromClient);

		for (int i = 0; i < 3; i++) {
			switch (i) {
			case 0:
				command = Integer.parseInt(commands[i]);
				break;
			case 1:
				account = commands[i];
				break;
			case 2:
				passwords = commands[i];
				break;
			}
		}
		JDBC jdbc = new JDBC(account, passwords);
		is_close = jdbc.createConnection();
		if (is_close) {
			dos.writeUTF("true");
			String accountInformation = jdbc.getAccountInformation(); // �÷��ؾͷ��أ�����Ͳ����������Ų��ᱨ����ָ�����
			dos.writeUTF(accountInformation);
			/****/
			dos.writeInt(jdbc.getmenuNum());
			String[] MenuInformation = jdbc.getMenuInformation();
			for (int i = 0; i < jdbc.getmenuNum(); i++) {
				dos.writeUTF(MenuInformation[i]);
			}
			/****/
			dos.writeInt(jdbc.getSongsInformationNum());
			String[] SongsInformation = jdbc.getSongsInformation();
			for (int i = 0; i < jdbc.getSongsInformationNum(); i++) {
				dos.writeUTF(SongsInformation[i]);
			}

			/****/
			dos.writeInt(jdbc.getFriendsNum());
			sentFriends(dos, jdbc.getFriends());
			/** ���������ļ����ݸ��ͻ��� **/
			File image = new File(jdbc.getIma());
			TransFile(image, dos);
			
			JOptionPane.showMessageDialog(null, "���Ϳͻ��˳ɹ�");

		} else {
			dos.writeUTF("false");
		}

	}

	public void TransFile(File f, DataOutputStream dos) throws IOException {
		DataInputStream fis = new DataInputStream(new FileInputStream(f));
		byte[] b = new byte[1024];
		int hasread;
		while ((hasread = fis.read(b)) != -1) {
			dos.write(b);
		}
		fis.close();
		dos.flush();
		dos.close();
		// bos.close();
	}

	private void sentFriends(DataOutputStream dos, String[] friends) throws IOException {
		// TODO Auto-generated method stub

		for (int i = 0; i < friends.length; i++) {
			dos.writeUTF(friends[i]);
		}
	}
}
