package NET;

public class CommandToSevers {
	public int command = 0;
	public String DownName = new String(" ");
        public CommandToSevers() {
        	
        }
}
