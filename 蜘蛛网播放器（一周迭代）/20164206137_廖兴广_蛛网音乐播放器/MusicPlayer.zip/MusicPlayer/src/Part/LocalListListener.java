package Part;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.media.NoPlayerException;
import javax.media.Time;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTree;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import NewMusic.LocalMusic;
import NewMusic.playMusic;

public class LocalListListener {
	JList list;

	String str = null;
	private int flag = 0;
	boolean Booleanflag = false; // ���ε��ʵ�ֲ��ź���ͣ
    ArrayList<String> songs = new GetList().getSongs();

	RoundLocation value = new RoundLocation(1); //���Ÿ�����λ          //0��location,1��Roundflag
	private GetLyrics getlyrics;
	
	public static playMusic p;
	private static MThreadRoundsongs over;

	public LocalListListener(JList list) {
		super();
		this.list = list;
	}

	public void listener(JButton b1, JButton b2, JButton b3,JSlider slider,JScrollPane js, DefaultListModel lcomdel, JList lyricList, JLabel Round, JTree tree) {
		
		/*���ż���*/
		list.addListSelectionListener(new ListSelectionListener() {


			@Override
			public void valueChanged(ListSelectionEvent e) {
				value.loctaion = 0;
				if(p != null) {
					p.close();             //        ʵ�ֲ����б��������б������б����ŵ��ν�
				}
				
				// TODO Auto-generated method stub
				flag = flag + 1; // ���ε�����

				if ((flag % 2) == 0) { // ����������
					
					str = (String) list.getSelectedValue();
					/** ���ò������ֵ��ಢ���벥���������� **/
					  p = new playMusic(str);
					try {
						p.getConnection();
					} catch (NoPlayerException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					
					p.start();  /*����Ӧʱ��*/
					try {
						Thread.sleep(30);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					slider.setMaximum((int) p.getDuration().getSeconds());
					System.out.println("has start");
					
					
					/** ���Ű�ť�������� **/
					/* ��һ�� */
					ActionListener b1Action = new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent arg0) {
							// TODO Auto-generated method stub
							over.interrupt();                                      //over����Ҳ���ж�switch���ʷ�ֹ�����ж�
							switch (value.Roundflag) {
							case 1:
								p.getPlayer().setPlaybackLoop(false);
								System.out.println("case1ִ����һ��");
								over.setLastOneRound();
								break;
							case 2:
								p.getPlayer().setPlaybackLoop(false);
								System.out.println("case2ִ����һ��");
								over.setRandom();
								break;
							case 3: 
			                    p.getPlayer().setPlaybackLoop(true);
			                    System.out.println("case3ִ����һ��");
			                    p.getPlayer().setMediaTime(new Time(0));
			                    break; 
							}
							/**�ж�ѭ���������ͽ��������������߳�**/
		                    over = new MThreadRoundsongs(p,value,songs,slider,getlyrics,Round, js , lcomdel , lyricList);
							over.start();
						}

					};
					b1.addActionListener(b1Action);

					/* ��ͣ���� */
					ActionListener b2Action = new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							if (!Booleanflag) {
								p.stop();
								Booleanflag = true;
								System.out.println("stop");
							} else {
								p.start();
								Booleanflag = false;
								System.out.println("start");
							}
						}

					};
					b2.addActionListener(b2Action);

					/* ��һ�� */
					ActionListener b3Action = new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							over.interrupt();
							switch (value.Roundflag) {
							case 1:
								p.getPlayer().setPlaybackLoop(false);
								System.out.println("case1ִ����һ��");
								over.setOneRound();
								break;
							case 2:
								p.getPlayer().setPlaybackLoop(false);
								System.out.println("case2ִ����һ��");
								over.setRandom();
								break;
							case 3: 
			                    p.getPlayer().setPlaybackLoop(true);
			                    System.out.println("case3ִ����һ��");
			                    p.getPlayer().setMediaTime(new Time(0));
			                    break;
							}

		                    over = new MThreadRoundsongs(p,value,songs,slider,getlyrics,Round,js , lcomdel , lyricList);
							over.start();
						}
					};

					b3.addActionListener(b3Action);
					
					
					/**������**/
					ChangeListener ch = new ChangeListener() {
						
						@Override
						public void stateChanged(ChangeEvent arg0) {
							// TODO Auto-generated method stub
							p.setMediaTime(new Time((double)slider.getValue()));
							System.out.println("Over");
						
							
							//JOptionPane.showMessageDialog(null, slider.getValue());
							
						}
					};
					slider.addMouseListener(new MouseListener() {
						
						@Override
						public void mouseReleased(MouseEvent e) {
							// TODO Auto-generated method stub
							
							
							
						}
						@Override
						public void mousePressed(MouseEvent e) {
							// TODO Auto-generated method stub
							slider.addChangeListener(ch);
						}
						
						@Override
						public void mouseExited(MouseEvent e) {
							// TODO Auto-generated method stub
							slider.removeChangeListener(ch);
						}
						
						@Override
						public void mouseEntered(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
						@Override
						public void mouseClicked(MouseEvent e) {
							// TODO Auto-generated method stub
						
						}
					});
				

					/*��ʹ���*/
					try {
						 getlyrics = new GetLyrics(p, js , lcomdel , lyricList,getSongName());
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					/*�ײ��Ŷ�λ*/
					Iterator itsongs = songs.iterator();
					while(itsongs.hasNext()) {
						if (itsongs.next().equals(str)) {
							break;
						}else {
							value.loctaion = value.loctaion + 1;
						}
					}
					
					/**�������̼߳���**/
					MThreadSlider Shownow = new MThreadSlider(p, slider);   //���߳���ʾ����
					Shownow.start();
					slider.setValue((int)p.getMediaTime().getSeconds());    //��������ʼ��
				    over = new MThreadRoundsongs(p,value,songs,slider,getlyrics,Round,js , lcomdel , lyricList);
					over.start();
					
					
					
					/** �ν���һ�ε�����л��������� **/
					list.addListSelectionListener(new ListSelectionListener() {

						@Override
						public void valueChanged(ListSelectionEvent e) {
							// TODO Auto-generated method stub
							if ((flag % 2) == 0) { // ���������ظ��Ĳ���
								over.interrupt();
								p.close();
								b2.removeActionListener(b2Action);// ����б������л�������ʱ��һ��������
								b1.removeActionListener(b1Action);
								b3.removeActionListener(b3Action);
								System.out.println(flag);
								list.removeListSelectionListener(this);
								
							}
						}
					});
				    
				}
			}
		});		

	}

	public String getSongName() {
		return str;
	}

	public static playMusic getP() {
		return p;
	}

	

	public void listenerOneTime(JButton b2,JSlider slider) {
		// TODO Auto-generated method stub
		list.addListSelectionListener(new ListSelectionListener() {

		public void valueChanged(ListSelectionEvent e) {
			if(p != null) {
				p.close();             //        ʵ�ֲ����б��������б������б����ŵ��ν�
			}
			
			// TODO Auto-generated method stub
			
				str = (String) list.getSelectedValue();
				try {
					over.interrupt();
				} catch (Exception e2) {
					// TODO: handle exception
				}
				try {
					p.close();     
				} catch (Exception e2) {
					// TODO: handle exception
				}
				                                //������������ʱ����ֹ�б���
				/** ���ò������ֵ��ಢ���벥���������� **/
				  p = new playMusic(str);
				try {
					p.getConnection();
				} catch (NoPlayerException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				p.start();  /*����Ӧʱ��*/
				try {
					Thread.sleep(30);
				} catch (InterruptedException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				slider.setMaximum((int) p.getDuration().getSeconds());
				System.out.println("has start");
				
				
				/** ���Ű�ť�������� **/

				/* ��ͣ���� */
				ActionListener b2Action = new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						// TODO Auto-generated method stub
						if (!Booleanflag) {
							p.stop();
							Booleanflag = true;
							System.out.println("stop");
						} else {
							p.start();
							Booleanflag = false;
							System.out.println("start");
						}
					}

				};
				b2.addActionListener(b2Action);
				
				
				/**������**/
				ChangeListener ch = new ChangeListener() {
					
					@Override
					public void stateChanged(ChangeEvent arg0) {
						// TODO Auto-generated method stub
						p.setMediaTime(new Time((double)slider.getValue()));
					
						
						//JOptionPane.showMessageDialog(null, slider.getValue());
						
					}
				};
				slider.addMouseListener(new MouseListener() {
					
					@Override
					public void mouseReleased(MouseEvent e) {
						// TODO Auto-generated method stub
						
						
						
					}
					@Override
					public void mousePressed(MouseEvent e) {
						// TODO Auto-generated method stub
						slider.addChangeListener(ch);
					}
					
					@Override
					public void mouseExited(MouseEvent e) {
						// TODO Auto-generated method stub
						slider.removeChangeListener(ch);
					}
					
					@Override
					public void mouseEntered(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}
					
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
					
					}
				});
			
			
				
				/**�������̼߳���**/
				MThreadSlider Shownow = new MThreadSlider(p, slider);   //���߳���ʾ����
				Shownow.start();
				slider.setValue((int)p.getMediaTime().getSeconds());    //��������ʼ��

				
//				/** �ν���һ�ε�����л��������� **/
//				list.addListSelectionListener(new ListSelectionListener() {
//
//					@Override
//					public void valueChanged(ListSelectionEvent e) {
//						// TODO Auto-generated method stub
//						if ((flag % 2) == 0) { // ���������ظ��Ĳ���
//							p.close();
//							b2.removeActionListener(b2Action);// ����б������л�������ʱ��һ��������
//							System.out.println(flag);
//							list.removeListSelectionListener(this);
//							
//						}
//					}
//				});
			list.removeListSelectionListener(this);
		}
		
	});	
		
	}
	


}

