package Part;

import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.TextArea;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;

import NewMusic.playMusic;

public class GetLyrics {

	private LyricsListener moveRound;

	public GetLyrics(playMusic p, JScrollPane js, DefaultListModel lcomdel, JList lyricList, String songName)
			throws IOException {

		lcomdel.removeAllElements();
		ArrayList<Timeer> lyrics = new ArrayList<>();
		int point;
		String t, name, type;
		String comment; // ��λ��
		int minute, seconds, Mseconds;
		String lyric;
		js.doLayout();

		/* ȥ����׺ */
		int houzhui = songName.indexOf(".");
		songName = songName.substring(0, houzhui);
		// JOptionPane.showMessageDialog(null, songName);

		File f = new File("C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\֩�벥������lyrics\\" + songName + "_���.lrc");
		if (f.exists()) { // ���޸��

			FileInputStream in = new FileInputStream(f);
			InputStreamReader inr = new InputStreamReader(in, "utf8");
			BufferedReader br = new BufferedReader(inr);

			for (int i = 0; i <= 3; i++) {
				lyric = br.readLine();
				point = lyric.indexOf("]");
				if (point < 0) {
					System.out.println("δ֪");
					continue;

				}
				t = lyric.substring(1, point);
				// type = lyric.substring(0, point);
				name = lyric.substring(point + 1);
				lyrics.add(new Timeer(t, name));
				System.out.print("��Դ��" + "���" + name);
				lcomdel.addElement(name);
			}

			while ((lyric = br.readLine()) != null) {
				point = lyric.indexOf("]");
				t = lyric.substring(1, point);
				comment = lyric.substring(point + 1);
				System.out.println("thisis" + t);
				lyrics.add(new Timeer(t, comment));
				if (comment.equals("")) {
					lcomdel.addElement("\n");
				} else {
					lcomdel.addElement(comment);
				}
				// System.out.println("����ʱ����:" + t + "||||||||||||�������ǣ�" +comment);
			}
			Iterator it = lyrics.iterator();
			while (it.hasNext()) {
				Timeer guodu = (Timeer) it.next(); // ��������JSC�ó�ȥ
				// �ı�����
			}
			// JOptionPane.showMessageDialog(null, "�����ʼ������");
			JScrollBar jb = js.getVerticalScrollBar(); // ��֪ʶ��
			// jb.setVisible(false);
			// jb.setValue(jb.getMaximum()); //��Ҫ��������SCPanel�����ֵ����

			// lyricsPanel.setOpaque(false);
			/* �Թ� */
			moveRound = new LyricsListener(lcomdel, lyricList, p, lyrics, jb);
			moveRound.start();
		} else {
			lcomdel.removeAllElements();
			lcomdel.addElement("�޸��");

		}
	}

}

class Timeer {
	private double minute, seconds, Mseconds, mtime;
	private int point;
	private String lyricTime;
	private String lyricComment;

	public Timeer(String lyricTime, String lyricComment) {
		super();
		this.lyricTime = lyricTime;
		this.lyricComment = lyricComment;

		point = lyricTime.indexOf(":");
		minute = Integer.valueOf(lyricTime.substring(0, point));
		lyricTime = lyricTime.substring(point + 1); // +1 ���б�Ҫ
		point = lyricTime.indexOf(".");
		seconds = Integer.valueOf(lyricTime.substring(0, point));
		Mseconds = Integer.valueOf(lyricTime.substring(point + 1));
		mtime = Mseconds + seconds * 1000 + minute * 60000;
		// JOptionPane.showMessageDialog(null, mtime);
	}

	public double getMtime() {
		return mtime / 100; // ��ȷ���Ⱥ�����һλ
	}

	public String getLyricComment() {
		return lyricComment;
	}
}

class LyricsListener extends Thread {
	private DefaultListModel lcomdel;
	private JList lyricList;
	private playMusic p;
	private ArrayList<Timeer> lyrics;
	private JScrollBar jb;
	private ListCellRenderer test;
	boolean is_over = true;

	public LyricsListener(DefaultListModel lcomdel, JList lyricList, playMusic p, ArrayList<Timeer> lyrics,
			JScrollBar jb) {
		super();
		this.lcomdel = lcomdel;
		this.lyricList = lyricList;
		this.p = p;
		this.lyrics = lyrics;
		this.jb = jb;
	}

	public void run() {
		while (is_over) {
			for (int i = 0; i < lyrics.size(); i++) {
				// System.out.println((int)(p.getMediaTime().getSeconds()*10));
				// System.out.println("���Ǹ�ʵ�ʱ�䣺"+(int)lyrics.get(i).getMtime());
				if ((int) lyrics.get(i).getMtime() == (int) (p.getMediaTime().getSeconds() * 10)) {

					Point p1 = lyricList.indexToLocation(i); // ȷ��List�ڼ���Ԫ�ص�λ��
					// System.out.println(p1.y+"����P������");
					jb.setValue(p1.y);// ���ô�ֱ������λ��
					lyricList.setSelectionForeground(Color.ORANGE);
					lyricList.setSelectedIndex(i + 4); // ȷ��List�ڼ���Ԫ��
					// test = lyricList.getCellRenderer();
					// test.getListCellRendererComponent( );
					lyricList.repaint();
				}
				if ((int) p.getMediaTime().getSeconds() == (int) p.getDuration().getSeconds()) {
					is_over = false;
				}
			}

		}
	}
}
