package Part;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class Graphics2DLyrics extends JPanel{
	
	public Graphics2DLyrics() throws Exception{
		JFrame frame = new JFrame();
		frame.setSize(300,300);
		frame.setVisible(true);
		frame.add(this);
		
	}

	
	public static void main(String[] args) throws Exception {
            new Graphics2DLyrics();
	}

	

	public void paint(Graphics g) {
		String lyric;
		File f = new File("C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\֩�벥������lyrics\\�����ĸ�_���.lrc");
		FileInputStream in;
		try {
			in = new FileInputStream(f);
			InputStreamReader inr = new InputStreamReader(in, "utf8");
		BufferedReader br = new BufferedReader(inr);g.drawRect(50, 50,200, 250);
		while ((lyric = br.readLine()) != null) {
			         g.drawString(lyric, 10, 10);
			
			
	}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
}
}
