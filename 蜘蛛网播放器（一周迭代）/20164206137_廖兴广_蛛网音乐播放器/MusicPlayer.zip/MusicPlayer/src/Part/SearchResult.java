package Part;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import javax.swing.ListModel;

public class SearchResult {
	private String text;
	private Vector<String> result;
	private String[] songs = new GetList().getSongstring();

	public SearchResult(String text) {
		// TODO Auto-generated constructor stub
		this.text=text;
	}
	
	/*����������ģ��ƥ��*/
  public Vector<String> putResult() {
	  result = new KMP(text).Judgement();
	  Iterator iterator = result.iterator();
      while (iterator.hasNext()) {
          System.out.println(iterator.next());
      }
	  return result;
  }
}
