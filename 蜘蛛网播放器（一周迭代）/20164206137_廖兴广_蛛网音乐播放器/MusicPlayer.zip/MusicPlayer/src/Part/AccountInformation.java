package Part;

public class AccountInformation {
       private String aname;
       private String aimg;
       private String atxt;
       public String getAname() {
		return aname;
	}
	public AccountInformation(String aname, String aimg, String atxt) {
		super();
		this.aname = aname;
		this.aimg = aimg;
		this.atxt = atxt;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getAimg() {
		return aimg;
	}
	public void setAimg(String aimg) {
		this.aimg = aimg;
	}
	public String getAtxt() {
		return atxt;
	}
	public void setAtxt(String atxt) {
		this.atxt = atxt;
	}
	
}
