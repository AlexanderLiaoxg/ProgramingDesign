package Part;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.media.NoPlayerException;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.ListCellRenderer;

import NewMusic.LocalMusic;
import NewMusic.playMusic;

public class MThreadRoundsongs extends Thread {
	private playMusic p;
	private RoundLocation value;
	private ArrayList<String> songs;
	private String str;
	private JSlider slider;
	private GetLyrics getlyrics;
	private JLabel Round;
	
	
	/**��ʹ���**/
	private DefaultListModel lcomdel;
	private JList lyricList;
	private ArrayList<Timeer> lyrics;
	private JScrollPane js;

	public MThreadRoundsongs(playMusic p, RoundLocation value, ArrayList<String> songs, JSlider slider,
			GetLyrics getlyrics, JLabel Round, JScrollPane js, DefaultListModel lcomdel, JList lyricList) {
		super();
		this.p = p;
		this.value = value;
		this.songs = songs;
		this.slider = slider;
		this.getlyrics = getlyrics;
		this.Round = Round;
		/*��ʹ���*/
		this.lcomdel = lcomdel;
		this.lyricList = lyricList;
		this.lyrics = lyrics;
		this.js = js;
		/** ѭ�������л� **/
		MouseListener RoundAction = new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				switch (value.Roundflag) {
				case 1:
					Round.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/random.png")));
					value.Roundflag = 2;
					break;
					
				case 2:
					Round.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/Onlyone.png")));
					value.Roundflag = 3;
					break;

				case 3:
					Round.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/oneRound.png")));
					value.Roundflag = 1;
					break;

				default:
					JOptionPane.showMessageDialog(null, "�л��������ֹ��ϣ�");
				}

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}
		};
		Round.addMouseListener(RoundAction);
	}

	public void run() {
		while (true) { 
			if(Thread.currentThread().isInterrupted()) {
				break;
			}
			if ((int) p.getMediaTime().getSeconds() == (int) p.getDuration().getSeconds()) {
				switch (value.Roundflag) {
				case 1:
					p.getPlayer().setPlaybackLoop(false);
					System.out.println("case1ִ����һ��");
					/**�������е�ʱ���**/
					if(Thread.currentThread().isInterrupted()) {
						break;
					}
					setOneRound();
					
					break;
				case 2:
					p.getPlayer().setPlaybackLoop(false);
					System.out.println("case2ִ����һ��");
					setRandom();
					if(Thread.currentThread().isInterrupted()) {
						break;
					}
					break;
				case 3: 
                    p.getPlayer().setPlaybackLoop(true);
                    System.out.println("case3ִ����һ��");
                    if(Thread.currentThread().isInterrupted()) {
						break;
					}
                    break;
				}
			}
		}
	}

	protected void setRandom() {
		// TODO Auto-generated method stub
		p.close();
		int r = value.loctaion;
		do {
			r = (int) (Math.random() * (songs.size() - 1));
		} while (r == value.loctaion);
		System.out.println("Ŀǰ������" + value.loctaion);
		value.loctaion = r;
		str = songs.get(value.loctaion);
		System.out.println("֮�������" + value.loctaion);

		playMusic p = new playMusic(str);
		try {
			p.getConnection();
			System.out.println("���ڲ��ţ�" + str);
			p.start();
		} catch (NoPlayerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Thread.sleep(30);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		slider.setMaximum((int) p.getDuration().getSeconds());

		
		try {
			getlyrics = new GetLyrics(p, js , lcomdel , lyricList,str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void setOneRound() {
		// TODO Auto-generated method stub	
		p.close();

		value.loctaion++;
		if (value.loctaion >= songs.size()) {
			value.loctaion = 0;
		}
			

		str = songs.get(value.loctaion);

		playMusic p = new playMusic(str);
		try {
			p.getConnection();
			p.start();
			System.out.println("���ڲ��ţ�" + str);
		} catch (NoPlayerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Thread.sleep(30);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		slider.setMaximum((int) p.getDuration().getSeconds());
		
		
		try {
			getlyrics = new GetLyrics(p, js , lcomdel , lyricList,str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void setLastOneRound() {
		// TODO Auto-generated method stub	
		p.close();

		value.loctaion--;
		if (value.loctaion < 0)
		{
			value.loctaion = songs.size() - 1 ;
		}

		str = songs.get(value.loctaion);

		playMusic p = new playMusic(str);
		try {
			p.getConnection();
			p.start();
			System.out.println("���ڲ��ţ�" + str);
		} catch (NoPlayerException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			Thread.sleep(30);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		slider.setMaximum((int) p.getDuration().getSeconds());

		
		try {
			getlyrics = new GetLyrics(p, js , lcomdel , lyricList,str);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
