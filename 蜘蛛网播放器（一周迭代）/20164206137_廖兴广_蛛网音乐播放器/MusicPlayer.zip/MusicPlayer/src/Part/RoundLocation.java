package Part;

public class RoundLocation {
      int loctaion;
      int Roundflag;



	public RoundLocation(int roundflag) {
		super();
		Roundflag = roundflag;
	}

	public int getLoctaion() {
		return loctaion;
	}

	public void setLoctaion(int loctaion) {
		this.loctaion = loctaion;
	}
}
