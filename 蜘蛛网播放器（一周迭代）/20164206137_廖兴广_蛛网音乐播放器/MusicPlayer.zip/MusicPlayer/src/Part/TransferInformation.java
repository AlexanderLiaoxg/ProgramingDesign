package Part;

import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;

import NewMusic.AccountCheck;

/** ��װ�û���Ϣ **/
public class TransferInformation {
	public String Daccount;
	public String Dpassword;
	public String name;
	public String ima;
	public String txt;
	public boolean hasChange = false;
	public boolean hasListChange = false;
	public String imageName;
	public String[] friends;
	public int friendsNum;
	public ArrayList<Songmenu> menu = new ArrayList<Songmenu>();
	public ArrayList<Songs> songs = new ArrayList<Songs>();
	
	public int menuNum;
	public int SongsNum;

	public TransferInformation() {
		super();
	}

	public void analyzInformation(String baseinformation) {
		String pat = "\\s"; // ��ַ�
		Pattern pattern = Pattern.compile(pat);
		String[] sum = pattern.split(baseinformation);
		System.out.println("������Ϣ��" + baseinformation);
		
		for (int i = 0; i < 5; i++) {
			switch (i) {
			case 0:
				Daccount = sum[i];
				break;
			case 1:
				Dpassword = sum[i];
				break;
			case 2:
				name = sum[i];
				break;
			case 3:
				imageName = sum[i];
				break;
			case 4:
				txt = sum[i];
				break;
			}
		}
	}
	
	public void analyzMenuInformation(String MenuInformation) {
		String pat = "\\s"; // ��ַ�
		Pattern pattern = Pattern.compile(pat);
		String[] sum = pattern.split(MenuInformation);
		System.out.println("�赥��Ϣ��" + MenuInformation);

			menu.add(new Songmenu(sum[0],Integer.parseInt(sum[1])));
	}
	
	public void analyzSongsInformation(String songsInformation) {
		// TODO Auto-generated method stub
		String pat = "\\s"; // ��ַ�
		Pattern pattern = Pattern.compile(pat);
		String[] sum = pattern.split(songsInformation);
		System.out.println("������Ϣ��" + songsInformation);
		songs.add(new Songs(sum[0], sum[1]));
	}
	
	public class Songmenu{
		String menuName;
		int songsNum;
		public Songmenu(String menuName, int songsNum) {
			super();
			this.menuName = menuName;
			this.songsNum = songsNum;
		}
		
		public String getMenuName() {
			return menuName;
		}
		public void setMenuName(String menuName) {
			this.menuName = menuName;
		}
		public int getSongsNum() {
			return songsNum;
		}
		public void setSongsNum(int songsNum) {
			this.songsNum = songsNum;
		}
	}
	
	public class Songs{
		String menu;
		String songs;
		public Songs(String menu, String songs) {
			super();
			this.menu = menu;
			this.songs = songs;
		}
		public String getMenu() {
			return menu;
		}
		public void setMenu(String menu) {
			this.menu = menu;
		}
		public String getSongs() {
			return songs;
		}
		public void setSongs(String songs) {
			this.songs = songs;
		}
		
	}


}
