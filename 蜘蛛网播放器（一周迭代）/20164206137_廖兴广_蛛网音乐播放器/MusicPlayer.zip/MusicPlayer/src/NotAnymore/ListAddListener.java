package NotAnymore;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class ListAddListener extends UI {
	private int flag = 0;
	private boolean FLAG = false; // FLAG�����Ƕ����

	public void Listener() {

		// ������������
		jList.addListSelectionListener(new ListSelectionListener() {// һ�ε������������

			@Override
			public void valueChanged(ListSelectionEvent e) {
				flag = flag + 1; // ���ε�����
				System.out.println(flag);

				if ((flag % 2) == 0) { // ����������
					String str = (String) jList.getSelectedValue();
					System.out.println(str + "�Ѿ��ɹ�");
					PlayMultithread my = new PlayMultithread(str);
					Thread th = new Thread(my);
					th.start(); // �е�Ī������
					jList.addListSelectionListener(new ListSelectionListener() {

						@Override
						public void valueChanged(ListSelectionEvent e) {
							th.interrupt();

						}
					});
					// th.stop();

					/** ��ť **/
					lb2.addActionListener(new ActionListener() {

						@Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub
							Object source = e.getSource(); // ��������
							synchronized (this) {
								if (source == lb2 && FLAG == false) {
									try {
										th.wait();
									} catch (InterruptedException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									System.out.println("has paused");
									FLAG = true;
								}
							}
							synchronized (this) {
								if (source == lb2 && FLAG == true) {
									th.notify();
									System.out.println("reback");
									FLAG = false;
								}
							}
						}
					});
				}
			}
		});

		/** ���ùرմ����˳����� **/
		frame.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowIconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeiconified(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowDeactivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowClosing(WindowEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

			@Override
			public void windowClosed(WindowEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void windowActivated(WindowEvent e) {
				// TODO Auto-generated method stub

			}
		});
	}

	public boolean isFLAG() {
		return FLAG;
	}

	public void setFLAG(boolean fLAG) {
		FLAG = fLAG;
	}

	// jbutton.add
}
