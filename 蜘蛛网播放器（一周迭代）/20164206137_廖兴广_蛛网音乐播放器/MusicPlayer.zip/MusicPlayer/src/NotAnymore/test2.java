package NotAnymore;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;


import javax.media.NoPlayerException;
import javax.media.Time;
import javax.media.bean.playerbean.MediaPlayer;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import MusicPlayer0.JAVAplayMusic;
import NewMusic.playMusic;



public class test2 {
	static playMusic p = new playMusic("֣С��� - ��.wav");
	static JFrame frame = new JFrame();
	static JPanel panel = new JPanel();
	static JSlider slider = new JSlider();
	static MediaPlayer play = p.Player();
public static void main(String[] args) throws NoPlayerException, IOException, Exception {
	frame.setBounds(100, 100, 450, 300);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.add(slider,BorderLayout.NORTH);
	frame.getContentPane().add(panel, BorderLayout.CENTER);
	panel.setLayout(null);
	
	p.getConnection();
	play.start();
	slider.setValue((int)play.getMediaTime().getSeconds());
	//slider.setValue((int)play.getMediaTime().getSeconds());
		play.setPlaybackLoop(true);                 //�����Ƿ����ò���
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 199, 432, 54);
		panel.add(panel_1);
		
		JProgressBar progressBar = new JProgressBar();
		panel_1.add(progressBar);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 432, 186);
		panel.add(panel_2);
		frame.setVisible(true);
	
//	slider.addChangeListener(new ChangeListener() {
//		
//		@Override
//		public void stateChanged(ChangeEvent e) {
//			// TODO Auto-generated method stub
//		
//			play.getGainControl().setLevel(0);         //����
//		}
//	});
	Thread.sleep(500);                                      //��������޷��õ���ȷ��ʱ��
	double time = 20;
	Time t = new Time(time);    //1��(s)=1000000000����(ns)

	//double time = p.getDuration().getSeconds();
	System.out.println(play.getMediaTime().getSeconds());
	System.out.println(p.getDuration().getSeconds());
	slider.setMaximum((int) p.getDuration().getSeconds());
	System.out.println(slider.getMaximum());
	//Thread.sleep(10000);
	//play.setMediaTime(t);

	ChangeListener ch = new ChangeListener() {
		
		@Override
		public void stateChanged(ChangeEvent arg0) {
			// TODO Auto-generated method stub
			play.setMediaTime(new Time((double)slider.getValue()));
			System.out.println("Over");
		
			
			//JOptionPane.showMessageDialog(null, slider.getValue());
			
		}
	};
	slider.addMouseListener(new MouseListener() {
		
		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
			
			
		}
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			slider.addChangeListener(ch);
		}
		
		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			slider.removeChangeListener(ch);
		}
		
		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		
		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
		
		}
	});
	while(true) {
		Thread.sleep(1000);                                       //  ����������Ӧ��ʱ�����������ò��ŵ㣬��������
		slider.setValue((int)play.getMediaTime().getSeconds());
	}
	
	
//	double i = 20;
//	while(true) {
//		System.out.println(play.getMediaTime().getSeconds());
//		if(play.getMediaTime().getSeconds()>i)
//		{
//			play.setMediaTime(t);
//		}
//	}
	
	
	
}
}
