package NotAnymore;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;

import NewMusic.AccountCheck;
import Part.GetList;

/*
 * ����Ϊ��ʼ�����࣬����ĵ�½label�������AccountCheck�෵���˺š������ж�ֵ��
 */
public class NewMusciUI {

	private JFrame frame;
	private JPasswordField passwordField;

	/**
	 * Create the application.
	 */
	public NewMusciUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u8718\u86DB\u64AD\u653E\u5668");
		frame.setBounds(100, 100, 737, 545);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setOpaque(false); // ���������Ϊ͸��
		panel.setBounds(0, 0, 719, 32);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		JLabel label = new JLabel("\u767B\u9646");
		label.setBounds(71, 0, 30, 32);
		panel.add(label);

		JPanel panel_7 = new JPanel();
		panel_7.setOpaque(false);

		panel_7.setBounds(0, 1, 719, 31);
		panel.add(panel_7);
		panel_7.setLayout(null);

		JLabel label_1 = new JLabel("");
		label_1.setEnabled(false);
		label_1.setBounds(107, 0, 30, 32);
		panel_7.add(label_1);
		label_1.setVerticalAlignment(SwingConstants.TOP);
		label_1.setIcon(new ImageIcon(NewMusciUI.class.getResource("/NewMusic/photos/skin.jpg")));
		label.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setText("��½");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setText("<html><u>��½</u></html>");
			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				new AccountCheck();
			}
		});

		JPanel panel_1 = new JPanel();
		panel_1.setOpaque(false);
		panel_1.setBounds(197, 273, 261, 56);
		frame.getContentPane().add(panel_1);

		JButton btnNewButton = new JButton("P");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});

		JButton btnNewButton_2 = new JButton("L");
		panel_1.add(btnNewButton_2);
		panel_1.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("N");
		panel_1.add(btnNewButton_1);

		JSlider slider = new JSlider();
		panel_1.add(slider);

		JPanel panel_2 = new JPanel();
		panel_2.setOpaque(false);
		panel_2.setBounds(0, 101, 197, 397);
		frame.getContentPane().add(panel_2);

		String songName[] = new GetList().getSongs();
		panel_2.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 0, 197, 397);
		panel_2.add(scrollPane);

		JScrollBar scrollBar_1 = new JScrollBar();
		scrollPane.setRowHeaderView(scrollBar_1);

		String[] SongName = new GetList().getSongs();
		JList list = new JList(SongName);
		scrollPane.setViewportView(list);

		JPanel panel_3 = new JPanel();
		panel_3.setOpaque(false);
		panel_3.setBounds(197, 33, 261, 241);
		frame.getContentPane().add(panel_3);
		panel_3.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("");
		ImageIcon head = new ImageIcon(NewMusciUI.class.getResource("/NewMusic/photos/MyPhoto.jpg"));
		/** ����Ӧ�����С��Image��������IMAGEICONdui **/

		lblNewLabel_1.setIcon(new ImageIcon(NewMusciUI.class.getResource("/NewMusic/photos/MyPhoto.jpg")));
		lblNewLabel_1.setBounds(0, 0, 260, 241);
		head.setImage(head.getImage().getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(),
				Image.SCALE_DEFAULT));
		panel_3.add(lblNewLabel_1);

		JPanel panel_4 = new JPanel();
		panel_4.setOpaque(false);
		panel_4.setBounds(458, 33, 261, 296);
		frame.getContentPane().add(panel_4);
		panel_4.setLayout(null);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane_1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
		scrollPane_1.setBounds(0, 0, 261, 296);
		panel_4.add(scrollPane_1);

		JList list_2 = new JList(SongName);
		scrollPane_1.setViewportView(list_2);

		JPanel panel_5 = new JPanel();
		panel_5.setOpaque(false);
		panel_5.setBounds(197, 326, 522, 148);
		frame.getContentPane().add(panel_5);
		panel_5.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u8BC4\u8BBA\uFF1A");
		lblNewLabel.setBounds(0, 0, 520, 47);
		panel_5.add(lblNewLabel);

		JList list_1 = new JList();
		list_1.setBounds(0, 47, 520, 107);
		panel_5.add(list_1);

		JPanel panel_6 = new JPanel();
		panel_6.setOpaque(false);
		panel_6.setBounds(197, 474, 522, 24);
		frame.getContentPane().add(panel_6);
		panel_6.setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("\u7559\u8A00\uFF1A");
		lblNewLabel_2.setBounds(0, 0, 45, 18);
		panel_6.add(lblNewLabel_2);

		passwordField = new JPasswordField();
		passwordField.setBounds(59, 0, 463, 24);
		panel_6.add(passwordField);

		JPanel panel_8 = new JPanel();
		panel_8.setOpaque(false);
		panel_8.setBounds(0, 33, 197, 70);
		frame.getContentPane().add(panel_8);

		JPanel panel_9 = new JPanel();
		panel_9.setBackground(Color.PINK);
		panel_9.setBounds(0, 0, 719, 498);
		frame.getContentPane().add(panel_9);
		frame.setVisible(true);
	}
}
