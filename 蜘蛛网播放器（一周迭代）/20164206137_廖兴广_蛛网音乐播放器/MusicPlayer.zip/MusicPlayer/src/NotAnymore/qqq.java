package NotAnymore;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import NewMusic.AccountCheck;
import NewMusic.LocalMusic;
import Part.AccountInformation;
import Part.GetList;
import java.awt.FlowLayout;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class qqq {

	private JFrame frame;
	private JTextField txtD;

	/**
	 * Create the application.
	 */
	public qqq() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 880, 613);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBackground(Color.blue);
		frame.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 11, 171, -108, 58, 156, 97, 0, 0 };
		gbl_panel.rowHeights = new int[] { 30, 0, 101, 68, -54, -20, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.anchor = GridBagConstraints.NORTH;
		gbc_panel_2.insets = new Insets(0, 0, 5, 5);
		gbc_panel_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_2.gridx = 0;
		gbc_panel_2.gridy = 0;
		panel.add(panel_2, gbc_panel_2);
		panel_2.setLayout(new GridLayout(1, 0, 0, 0));

		JLabel lblNewLabel = new JLabel("\u767B\u9646");
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		panel_2.add(lblNewLabel);
		lblNewLabel.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				lblNewLabel.setText("��½");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				lblNewLabel.setText("<html><u>��½</u></html>");
			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				new AccountCheck();
			}
		});
		
		JPanel panel_23 = new JPanel();
		GridBagConstraints gbc_panel_23 = new GridBagConstraints();
		gbc_panel_23.gridwidth = 2;
		gbc_panel_23.insets = new Insets(0, 0, 5, 5);
		gbc_panel_23.fill = GridBagConstraints.BOTH;
		gbc_panel_23.gridx = 1;
		gbc_panel_23.gridy = 0;
		panel.add(panel_23, gbc_panel_23);
		GridBagLayout gbl_panel_23 = new GridBagLayout();
		gbl_panel_23.columnWidths = new int[]{63, 0, 0};
		gbl_panel_23.rowHeights = new int[]{0, 0, 0};
		gbl_panel_23.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_23.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		panel_23.setLayout(gbl_panel_23);
		

		/**�û���Ϣ���ֱ�ǩ**/
		/*ͷ��*/
		JLabel lblNewLabel_8 = new JLabel();
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 0;
		gbc_lblNewLabel_8.gridy = 0;
		//lblNewLabel_8.setText(JDBC.ainformation.getAimg());
		panel_23.add(lblNewLabel_8, gbc_lblNewLabel_8);
		
		/*����*/
		JLabel lblNewLabel_9 = new JLabel("");
		GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
		gbc_lblNewLabel_9.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_9.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel_9.gridx = 1;
		gbc_lblNewLabel_9.gridy = 0;
		//lblNewLabel_9.setText(JDBC.ainformation.getAname());
		panel_23.add(lblNewLabel_9, gbc_lblNewLabel_9);
		
		/*����ǩ��*/
		JLabel lblNewLabel_7 = new JLabel("");
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.gridwidth = 2;
		gbc_lblNewLabel_7.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_7.fill = GridBagConstraints.VERTICAL;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_7.gridx = 0;
		gbc_lblNewLabel_7.gridy = 1;
		//lblNewLabel_7.setText(JDBC.ainformation.getAtxt());
		panel_23.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		JPanel panel_22 = new JPanel();
		GridBagConstraints gbc_panel_22 = new GridBagConstraints();
		gbc_panel_22.gridwidth = 2;
		gbc_panel_22.anchor = GridBagConstraints.NORTH;
		gbc_panel_22.insets = new Insets(0, 0, 5, 5);
		gbc_panel_22.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_22.gridx = 3;
		gbc_panel_22.gridy = 0;
		panel.add(panel_22, gbc_panel_22);
		GridBagLayout gbl_panel_22 = new GridBagLayout();
		gbl_panel_22.columnWidths = new int[]{0, 0, 0};
		gbl_panel_22.rowHeights = new int[]{0, 0, 0};
		gbl_panel_22.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_22.rowWeights = new double[]{1.0, 0.0, Double.MIN_VALUE};
		panel_22.setLayout(gbl_panel_22);
		
		JLabel lblIcon = new JLabel("icon");
		GridBagConstraints gbc_lblIcon = new GridBagConstraints();
		gbc_lblIcon.insets = new Insets(0, 0, 5, 5);
		gbc_lblIcon.gridx = 0;
		gbc_lblIcon.gridy = 0;
		panel_22.add(lblIcon, gbc_lblIcon);
		
		JTextArea textArea = new JTextArea();
		GridBagConstraints gbc_textArea = new GridBagConstraints();
		gbc_textArea.insets = new Insets(0, 0, 5, 0);
		gbc_textArea.fill = GridBagConstraints.BOTH;
		gbc_textArea.gridx = 1;
		gbc_textArea.gridy = 0;
		panel_22.add(textArea, gbc_textArea);

		JPanel panel_11 = new JPanel();
		GridBagConstraints gbc_panel_11 = new GridBagConstraints();
		gbc_panel_11.anchor = GridBagConstraints.NORTH;
		gbc_panel_11.gridwidth = 2;
		gbc_panel_11.insets = new Insets(0, 0, 5, 0);
		gbc_panel_11.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_11.gridx = 5;
		gbc_panel_11.gridy = 0;
		panel.add(panel_11, gbc_panel_11);
		panel_11.setLayout(new GridLayout(1, 0, 0, 0));

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel_1.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/skin.jpg")));
		panel_11.add(lblNewLabel_1);
		String[] SongName = new GetList().getSongs();
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.anchor = GridBagConstraints.WEST;
		gbc_panel_1.gridheight = 5;
		gbc_panel_1.insets = new Insets(0, 0, 5, 5);
		gbc_panel_1.fill = GridBagConstraints.VERTICAL;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 1;
		panel.add(panel_1, gbc_panel_1);
		panel_1.setLayout(new GridLayout(9, 0, 0, 0));
		
		JPanel panel_6 = new JPanel();
		panel_1.add(panel_6);
		
		JPanel panel_12 = new JPanel();
		panel_1.add(panel_12);
		
		JPanel panel_13 = new JPanel();
		panel_1.add(panel_13);
		
		JLabel lblNewLabel_2 = new JLabel("\u9996\u9875");
		panel_13.add(lblNewLabel_2);
		
		JPanel panel_5 = new JPanel();
		panel_1.add(panel_5);
		
		JLabel lblNewLabel_3 = new JLabel("\u672C\u5730\u6B4C\u66F2");
		panel_5.add(lblNewLabel_3);
		
		JPanel panel_14 = new JPanel();
		panel_1.add(panel_14);
		
		JLabel lblNewLabel_4 = new JLabel("\u6211\u7684\u6B4C\u5355");
		panel_14.add(lblNewLabel_4);
		
		JPanel panel_15 = new JPanel();
		panel_1.add(panel_15);
		
		JPanel panel_16 = new JPanel();
		panel_1.add(panel_16);
		
		JPanel panel_17 = new JPanel();
		panel_1.add(panel_17);
		
		JPanel panel_18 = new JPanel();
		panel_1.add(panel_18);

		JPanel panel_9 = new JPanel();
		GridBagConstraints gbc_panel_9 = new GridBagConstraints();
		gbc_panel_9.gridheight = 3;
		gbc_panel_9.gridwidth = 2;
		gbc_panel_9.insets = new Insets(0, 0, 5, 5);
		gbc_panel_9.fill = GridBagConstraints.BOTH;
		gbc_panel_9.gridx = 2;
		gbc_panel_9.gridy = 1;
		panel.add(panel_9, gbc_panel_9);
		panel_9.setLayout(new GridLayout(0, 1, 0, 0));

		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_6.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/MyPhoto.jpg")));
		panel_9.add(lblNewLabel_6);

		JPanel panel_10 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_10.getLayout();
		flowLayout.setAlignment(FlowLayout.LEFT);
		JScrollPane scrollPane3 = new JScrollPane();
		String[] SongName3 = new GetList().getSongs();
		JList list3 = new JList(SongName3);
		scrollPane3.setViewportView(list3);
		panel_10.add(scrollPane3);
		GridBagConstraints gbc_panel_10 = new GridBagConstraints();
		gbc_panel_10.gridheight = 3;
		gbc_panel_10.gridwidth = 3;
		gbc_panel_10.insets = new Insets(0, 0, 5, 0);
		gbc_panel_10.fill = GridBagConstraints.BOTH;
		gbc_panel_10.gridx = 4;
		gbc_panel_10.gridy = 1;
		panel.add(panel_10, gbc_panel_10);

		JPanel panel_4 = new JPanel();
		GridBagConstraints gbc_panel_4 = new GridBagConstraints();
		gbc_panel_4.fill = GridBagConstraints.BOTH;
		gbc_panel_4.gridheight = 5;
		gbc_panel_4.insets = new Insets(0, 0, 5, 5);
		gbc_panel_4.gridx = 1;
		gbc_panel_4.gridy = 1;
		panel.add(panel_4, gbc_panel_4);

		JScrollPane scrollPane_1 = new JScrollPane();
		String[] SongName2 = new GetList().getSongs();
		panel_4.setLayout(new GridLayout(0, 1, 0, 0));
		JList list2 = new JList(SongName);
		scrollPane_1.setViewportView(list2);
		panel_4.add(scrollPane_1);

		JPanel panel_8 = new JPanel();
		GridBagConstraints gbc_panel_8 = new GridBagConstraints();
		gbc_panel_8.gridwidth = 5;
		gbc_panel_8.insets = new Insets(0, 0, 5, 0);
		gbc_panel_8.fill = GridBagConstraints.BOTH;
		gbc_panel_8.gridx = 2;
		gbc_panel_8.gridy = 4;
		panel.add(panel_8, gbc_panel_8);

		JLabel lblNewLabel_5 = new JLabel("New label");
		panel_8.add(lblNewLabel_5);

		JPanel panel_7 = new JPanel();
		GridBagConstraints gbc_panel_7 = new GridBagConstraints();
		gbc_panel_7.gridwidth = 5;
		gbc_panel_7.insets = new Insets(0, 0, 5, 0);
		gbc_panel_7.fill = GridBagConstraints.BOTH;
		gbc_panel_7.gridx = 2;
		gbc_panel_7.gridy = 5;
		panel.add(panel_7, gbc_panel_7);
		panel_7.setLayout(new GridLayout(0, 1, 0, 0));

		txtD = new JTextField();
		txtD.setText(
				"dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd");
		panel_7.add(txtD);
		txtD.setColumns(10);

		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.anchor = GridBagConstraints.SOUTH;
		gbc_panel_3.gridwidth = 7;
		gbc_panel_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 6;
		panel.add(panel_3, gbc_panel_3);
		panel_3.setLayout(new GridLayout(0, 8, 0, 0));
		
		JPanel panel_19 = new JPanel();
		panel_3.add(panel_19);

		JButton btnNewButton = new JButton("last");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		panel_3.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("p/s");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_3.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("next");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_3.add(btnNewButton_2);

		JSlider slider = new JSlider();
		panel_3.add(slider);
		
		JPanel panel_20 = new JPanel();
		panel_3.add(panel_20);
		
		JPanel panel_21 = new JPanel();
		panel_3.add(panel_21);
		
		frame.setVisible(true);
	}
}
