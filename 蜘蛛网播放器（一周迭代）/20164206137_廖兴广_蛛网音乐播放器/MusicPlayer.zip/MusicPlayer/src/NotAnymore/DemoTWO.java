package NotAnymore;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.SwingConstants;

import NewMusic.AccountCheck;
import Part.GetList;

public class DemoTWO {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DemoTWO window = new DemoTWO();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public DemoTWO() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 623, 516);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));

		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		panel.setOpaque(false); // ���������Ϊ͸��

		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.NORTH);

		JLabel label = new JLabel("\u767B\u9646");
		panel_1.add(label);

		JLabel label_1 = new JLabel("");
		panel_1.add(label_1);
		label_1.setIcon(new ImageIcon(DemoTWO.class.getResource("/NewMusic/photos/skin.jpg")));
		label_1.setVerticalAlignment(SwingConstants.TOP);
		label_1.setEnabled(false);
		label.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setText("��½");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				label.setText("<html><u>��½</u></html>");
			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				new AccountCheck();
			}
		});
		panel_1.setOpaque(false);

		JPanel panel_2 = new JPanel();
		panel_2.setPreferredSize(new Dimension(300, 600));
		panel_2.setOpaque(false);
		panel.add(panel_2, BorderLayout.WEST);

		JScrollPane scrollPane = new JScrollPane();
		panel_2.add(scrollPane);

		String[] SongName = new GetList().getSongs();
		JList list = new JList(SongName);
		scrollPane.setViewportView(list);

		JPanel panel_3 = new JPanel();
		JScrollPane scrollPane2 = new JScrollPane();
		panel_2.add(scrollPane);

		String[] SongName2 = new GetList().getSongs();
		JList list2 = new JList(SongName2);
		scrollPane2.setViewportView(list2);
		panel.add(panel_3, BorderLayout.EAST);

		JPanel panel_4 = new JPanel();
		panel.add(panel_4, BorderLayout.SOUTH);

		JButton btnNewButton = new JButton("L");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		panel_4.setLayout(new GridLayout(0, 4, 0, 0));
		panel_4.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("P");
		panel_4.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("N");
		panel_4.add(btnNewButton_2);

		JSlider slider = new JSlider();
		panel_4.add(slider);

		JPanel panel_5 = new JPanel();
		panel.add(panel_5, BorderLayout.CENTER);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(DemoTWO.class.getResource("/NewMusic/photos/MyPhoto.jpg")));
		panel_5.add(lblNewLabel);
	}
}
