package NotAnymore;

import java.awt.EventQueue;
import java.io.IOException;

import javax.media.NoPlayerException;
import javax.media.Time;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JProgressBar;

import com.sun.media.rtsp.Timer;

import MusicPlayer0.JAVAplayMusic;
import NewMusic.playMusic;

public class teste {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					teste window = new teste();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public teste() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		playMusic p = new playMusic("֣С��� - ��.wav");
		try {
			p.getConnection();
		} catch (NoPlayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    p.start();
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 199, 432, 54);
		panel.add(panel_1);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setMaximum(12);
		progressBar.setBackground(Color.pink);
		//progressBar.addChangeListener(l);
		Timer t = new Timer(null, 0);
		System.out.println(p.getMediaTime());
		//progressBar
		//progressBar.setValue(n);
		 
		panel_1.add(progressBar);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 0, 432, 186);
		panel.add(panel_2);
	}

}
