package NotAnymore;

import MusicPlayer0.JAVAplayMusic;

public class PlayMultithread implements Runnable {

	String str;

	public PlayMultithread(String str) {
		super();
		this.str = str;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stu
		synchronized (this) {
			new JAVAplayMusic(str);
			System.out.println(str);
		}
	}
}