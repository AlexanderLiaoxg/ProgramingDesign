package NewMusic;

import java.io.IOException;

import javax.media.NoPlayerException;

public class ONE {

	public static void main(String[] args) throws Exception {
		new LocalMusic();
		// new NewMusciUI();
	}
}
