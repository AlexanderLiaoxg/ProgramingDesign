package NewMusic;

import java.io.IOException;

import javax.media.NoPlayerException;

import NewMusic.playMusic;

public class PlayThread implements Runnable{
	String str;

	public PlayThread(String str) {
		this.str = str;
	}

	@Override
	public void run() {
		// TODO Auto-generated method str
		synchronized (this) {
			playMusic p = new playMusic(str);
			try {
				p.getConnection();
			} catch (NoPlayerException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			p.start();
		}
	}

}
