package NewMusic;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.media.NoPlayerException;
import javax.swing.AbstractButton;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import NET.CommandToSevers;
import NET.PlayerClient;
import Part.AccountInformation;
import Part.GetList;
import Part.LocalListListener;
import Part.SearchResult;
import Part.TransferInformation;

import java.awt.FlowLayout;
import javax.swing.JTextArea;
import javax.swing.JTabbedPane;
import javax.swing.JProgressBar;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import java.awt.BorderLayout;
import javax.swing.JSeparator;
import javax.swing.JTree;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class LocalMusic {
	private JFrame frame;
	private JTextField textField;
	private Boolean is_connect = false;

	/**
	 * Create the application.
	 * @throws Exception 
	 */
	public LocalMusic() throws Exception {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 * @throws NoPlayerException 
	 */
	private void initialize() throws Exception {
		frame = new JFrame();
		frame.setBounds(100, 100, 880, 613);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBackground(Color.blue);
		frame.getContentPane().setLayout(new GridLayout(1, 0, 0, 0));

		/**�����ͻ���**/
		TransferInformation information = new TransferInformation();
		CommandToSevers doit = new CommandToSevers();
		try {
			PlayerClient client = new PlayerClient(doit,information);
			is_connect = true;
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(null, "�޷����ӵ������");
		}
		
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[] { 59, 171, -108, 58, 156, 97, 0, 0 };
		gbl_panel.rowHeights = new int[] { 30, 0, 101, 68, -54, -20, 0, 0 };
		gbl_panel.columnWeights = new double[] { 0.0, 1.0, 1.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE };
		gbl_panel.rowWeights = new double[] { 0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE };
		panel.setLayout(gbl_panel);

		JPanel panel_2 = new JPanel();
		GridBagConstraints gbc_panel_2 = new GridBagConstraints();
		gbc_panel_2.anchor = GridBagConstraints.NORTH;
		gbc_panel_2.insets = new Insets(0, 0, 5, 5);
		gbc_panel_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_2.gridx = 0;
		gbc_panel_2.gridy = 0;
		panel.add(panel_2, gbc_panel_2);
		panel_2.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_23 = new JPanel();
		GridBagConstraints gbc_panel_23 = new GridBagConstraints();
		gbc_panel_23.anchor = GridBagConstraints.NORTH;
		gbc_panel_23.gridwidth = 2;
		gbc_panel_23.insets = new Insets(0, 0, 5, 5);
		gbc_panel_23.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_23.gridx = 1;
		gbc_panel_23.gridy = 0;
		panel.add(panel_23, gbc_panel_23);
		GridBagLayout gbl_panel_23 = new GridBagLayout();
		gbl_panel_23.columnWidths = new int[]{63, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel_23.rowHeights = new int[]{0, 0, 0};
		gbl_panel_23.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_23.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		panel_23.setLayout(gbl_panel_23);
		

		/**�û���Ϣ���ֱ�ǩ**/
		
		/*ͷ��*/
		JLabel lblNewLabel_8 = new JLabel();
		lblNewLabel_8.setText("");
		GridBagConstraints gbc_lblNewLabel_8 = new GridBagConstraints();
		gbc_lblNewLabel_8.fill = GridBagConstraints.VERTICAL;
		gbc_lblNewLabel_8.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_8.gridx = 0;
		gbc_lblNewLabel_8.gridy = 0;
		//lblNewLabel_8.setText(JDBC.ainformation.getAimg());
		panel_23.add(lblNewLabel_8, gbc_lblNewLabel_8);
		
		/*����*/

		JLabel lblNewLabel_9 = new JLabel("");
		GridBagConstraints gbc_lblNewLabel_9 = new GridBagConstraints();
		gbc_lblNewLabel_9.fill = GridBagConstraints.VERTICAL;
		gbc_lblNewLabel_9.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_9.gridx = 1;
		gbc_lblNewLabel_9.gridy = 0;
		//lblNewLabel_9.setText(JDBC.ainformation.getAname());
		panel_23.add(lblNewLabel_9, gbc_lblNewLabel_9);
		
		/*����ǩ��*/
		JLabel lblNewLabel_7 = new JLabel("WHAT DID I SAY");
		GridBagConstraints gbc_lblNewLabel_7 = new GridBagConstraints();
		gbc_lblNewLabel_7.anchor = GridBagConstraints.WEST;
		gbc_lblNewLabel_7.insets = new Insets(0, 0, 0, 5);
		gbc_lblNewLabel_7.gridwidth = 10;
		gbc_lblNewLabel_7.fill = GridBagConstraints.VERTICAL;
		gbc_lblNewLabel_7.gridx = 0;
		gbc_lblNewLabel_7.gridy = 1;
		//lblNewLabel_7.setText(JDBC.ainformation.getAtxt());
		panel_23.add(lblNewLabel_7, gbc_lblNewLabel_7);
		
		JPanel panel_22 = new JPanel();
		GridBagConstraints gbc_panel_22 = new GridBagConstraints();
		gbc_panel_22.gridwidth = 2;
		gbc_panel_22.anchor = GridBagConstraints.NORTH;
		gbc_panel_22.insets = new Insets(0, 0, 5, 5);
		gbc_panel_22.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_22.gridx = 3;
		gbc_panel_22.gridy = 0;
		panel.add(panel_22, gbc_panel_22);
		GridBagLayout gbl_panel_22 = new GridBagLayout();
		gbl_panel_22.columnWidths = new int[]{33, 0, 0, 0};
		gbl_panel_22.rowHeights = new int[]{0, 0, 0};
		gbl_panel_22.columnWeights = new double[]{0.0, 1.0, 1.0, Double.MIN_VALUE};
		gbl_panel_22.rowWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
		panel_22.setLayout(gbl_panel_22);
		
		/*��½*/
		JLabel lblNewLabel = new JLabel("\u767B\u9646");
		lblNewLabel.setFont(new Font("Serif", Font.PLAIN, 18));
		panel_2.add(lblNewLabel);
		lblNewLabel.addMouseListener(new MouseListener() {



			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				if(lblNewLabel.getText().equals("<html><u>�˳�</u></html>"))
				{
					lblNewLabel.setText("�˳�");
				}else {
				lblNewLabel.setText("��½");
				}
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				if(lblNewLabel.getText().equals("�˳�"))
				{
					lblNewLabel.setText("<html><u>�˳�</u></html>");
				}else {
				lblNewLabel.setText("<html><u>��½</u></html>");
				}
			}

			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
				
				if(lblNewLabel.getText().equals("<html><u>��½</u></html>") && is_connect){
					doit.command =1 ;
					if(information.hasChange)
					{
						lblNewLabel.setText(information.name);
					}
				}else {
					if(lblNewLabel.getText().equals("<html><u>�˳�</u></html>")) {
						lblNewLabel.setText("�˳�");
						lblNewLabel_9.setText("");
						lblNewLabel_8.setIcon(new ImageIcon());
						lblNewLabel_7.setText("");
						lblNewLabel.setText("��½");

					}else {
						JOptionPane.showMessageDialog(null, "ERROR!!!");
					}
				}		
				   
			}
		});
		
		/**�����򲿼�**/
		/*����ͼ��*/
		JLabel lblIcon = new JLabel("");
		lblIcon.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/search.png")));
		GridBagConstraints gbc_lblIcon = new GridBagConstraints();
		gbc_lblIcon.anchor = GridBagConstraints.EAST;
		gbc_lblIcon.insets = new Insets(0, 0, 5, 5);
		gbc_lblIcon.gridx = 0;
		gbc_lblIcon.gridy = 0;
		panel_22.add(lblIcon, gbc_lblIcon);
		
		textField = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.gridwidth = 2;
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 1;
		gbc_textField.gridy = 0;
		panel_22.add(textField, gbc_textField);
		textField.setColumns(10);

		
		JPanel panel_11 = new JPanel();
		GridBagConstraints gbc_panel_11 = new GridBagConstraints();
		gbc_panel_11.gridwidth = 2;
		gbc_panel_11.anchor = GridBagConstraints.NORTH;
		gbc_panel_11.insets = new Insets(0, 0, 5, 0);
		gbc_panel_11.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_11.gridx = 5;
		gbc_panel_11.gridy = 0;
		panel.add(panel_11, gbc_panel_11);
		panel_11.setLayout(new GridLayout(1, 0, 0, 0));
		
				JLabel lblNewLabel_1 = new JLabel("");
				lblNewLabel_1.setHorizontalAlignment(SwingConstants.TRAILING);
				lblNewLabel_1.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/skin.jpg")));
				panel_11.add(lblNewLabel_1);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.LEFT);
		GridBagConstraints gbc_tabbedPane = new GridBagConstraints();
		gbc_tabbedPane.gridheight = 5;
		gbc_tabbedPane.gridwidth = 7;
		gbc_tabbedPane.insets = new Insets(0, 0, 5, 5);
		gbc_tabbedPane.fill = GridBagConstraints.BOTH;
		gbc_tabbedPane.gridx = 0;
		gbc_tabbedPane.gridy = 1;
		panel.add(tabbedPane, gbc_tabbedPane);
		String[] SongName21 = new GetList().getSongstring();

		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("���ظ���", null, panel_1, null);
		GridBagLayout gbl_panel_1 = new GridBagLayout();
		gbl_panel_1.columnWidths = new int[]{284, -36, 303, 89, 0, 0, 0};
		gbl_panel_1.rowHeights = new int[]{0, 0, 254, 0, 0, 0};
		gbl_panel_1.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_1.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_1.setLayout(gbl_panel_1);
		
		JPanel panel_5 = new JPanel();
		GridBagConstraints gbc_panel_5 = new GridBagConstraints();
		gbc_panel_5.gridheight = 5;
		gbc_panel_5.insets = new Insets(0, 0, 0, 5);
		gbc_panel_5.fill = GridBagConstraints.BOTH;
		gbc_panel_5.gridx = 0;
		gbc_panel_5.gridy = 0;
		panel_1.add(panel_5, gbc_panel_5);
		panel_5.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_6 = new JPanel();
		GridBagConstraints gbc_panel_6 = new GridBagConstraints();
		gbc_panel_6.gridheight = 3;
		gbc_panel_6.gridwidth = 2;
		gbc_panel_6.insets = new Insets(0, 0, 5, 5);
		gbc_panel_6.fill = GridBagConstraints.BOTH;
		gbc_panel_6.gridx = 1;
		gbc_panel_6.gridy = 0;
		panel_1.add(panel_6, gbc_panel_6);
		panel_6.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/MyPhoto.jpg")));
		panel_6.add(lblNewLabel_2);
		
		/*��ʹ�������
		 * ���
		 * */
		JPanel panel_7 = new JPanel();
		GridBagConstraints gbc_panel_7 = new GridBagConstraints();
		gbc_panel_7.gridheight = 3;
		gbc_panel_7.gridwidth = 3;
		gbc_panel_7.insets = new Insets(0, 0, 5, 0);
		gbc_panel_7.fill = GridBagConstraints.BOTH;
		gbc_panel_7.gridx = 3;
		gbc_panel_7.gridy = 0;
		panel_1.add(panel_7, gbc_panel_7);
		panel_7.setLayout(new GridLayout(1,1));
		DefaultListModel  lcomdel = new DefaultListModel();
		lcomdel.addElement("\n");
        JList lyricList = new JList(lcomdel);
        JScrollPane js = new JScrollPane(lyricList);
        panel_7.add(js);

		JPanel panel_8 = new JPanel();
		GridBagConstraints gbc_panel_8 = new GridBagConstraints();
		gbc_panel_8.gridwidth = 5;
		gbc_panel_8.insets = new Insets(0, 0, 5, 0);
		gbc_panel_8.fill = GridBagConstraints.BOTH;
		gbc_panel_8.gridx = 1;
		gbc_panel_8.gridy = 3;
		panel_1.add(panel_8, gbc_panel_8);
		GridBagLayout gbl_panel_8 = new GridBagLayout();
		gbl_panel_8.columnWidths = new int[]{0, 0, 0, 0, 0};
		gbl_panel_8.rowHeights = new int[]{0, 0, 0, 0};
		gbl_panel_8.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_8.rowWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		panel_8.setLayout(gbl_panel_8);
		
		JLabel label_1 = new JLabel("\u8BC4\u8BBA\uFF1A");
		GridBagConstraints gbc_label_1 = new GridBagConstraints();
		gbc_label_1.insets = new Insets(0, 0, 5, 5);
		gbc_label_1.gridx = 0;
		gbc_label_1.gridy = 0;
		panel_8.add(label_1, gbc_label_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_2 = new GridBagConstraints();
		gbc_scrollPane_2.gridheight = 2;
		gbc_scrollPane_2.gridwidth = 4;
		gbc_scrollPane_2.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPane_2.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_2.gridx = 0;
		gbc_scrollPane_2.gridy = 1;
		panel_8.add(scrollPane_2, gbc_scrollPane_2);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setLineWrap(true);
		textArea_1.setEditable(false);
		scrollPane_2.setViewportView(textArea_1);
		
		JPanel panel_12 = new JPanel();
		GridBagConstraints gbc_panel_12 = new GridBagConstraints();
		gbc_panel_12.insets = new Insets(0, 0, 0, 5);
		gbc_panel_12.fill = GridBagConstraints.BOTH;
		gbc_panel_12.gridx = 1;
		gbc_panel_12.gridy = 4;
		panel_1.add(panel_12, gbc_panel_12);
		panel_12.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel label = new JLabel("\u7559\u8A00\uFF1A");
		panel_12.add(label);
		
		JPanel panel_9 = new JPanel();
		GridBagConstraints gbc_panel_9 = new GridBagConstraints();
		gbc_panel_9.gridwidth = 4;
		gbc_panel_9.fill = GridBagConstraints.BOTH;
		gbc_panel_9.gridx = 2;
		gbc_panel_9.gridy = 4;
		panel_1.add(panel_9, gbc_panel_9);
		GridBagLayout gbl_panel_9 = new GridBagLayout();
		gbl_panel_9.columnWidths = new int[]{296, 296, 0, 0};
		gbl_panel_9.rowHeights = new int[]{27, 0};
		gbl_panel_9.columnWeights = new double[]{1.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_9.rowWeights = new double[]{1.0, Double.MIN_VALUE};
		panel_9.setLayout(gbl_panel_9);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_3 = new GridBagConstraints();
		gbc_scrollPane_3.gridwidth = 3;
		gbc_scrollPane_3.insets = new Insets(0, 0, 0, 5);
		gbc_scrollPane_3.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_3.gridx = 0;
		gbc_scrollPane_3.gridy = 0;
		panel_9.add(scrollPane_3, gbc_scrollPane_3);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setLineWrap(true);
		scrollPane_3.setViewportView(textArea_2);
		
		JPanel panel_10 = new JPanel();
		tabbedPane.addTab("��ҳ", null, panel_10, null);
		panel_10.setLayout(new GridLayout(1, 0, 0, 0));
		
		
		JPanel panel_15 = new JPanel();
		tabbedPane.addTab("����", null, panel_15, null);
		panel_15.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_16 = new JPanel();
		panel_15.add(panel_16);
		GridBagLayout gbl_panel_16 = new GridBagLayout();
		gbl_panel_16.columnWidths = new int[]{57, 0, 0, 0, -131, 144, 0, 0, 0, 0, 0, 0, 49, 82, 61, -18, 0};
		gbl_panel_16.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel_16.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_panel_16.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, Double.MIN_VALUE};
		panel_16.setLayout(gbl_panel_16);
		
		JSeparator separator = new JSeparator();
		GridBagConstraints gbc_separator = new GridBagConstraints();
		gbc_separator.gridheight = 8;
		gbc_separator.insets = new Insets(0, 0, 5, 5);
		gbc_separator.gridx = 4;
		gbc_separator.gridy = 0;
		panel_16.add(separator, gbc_separator);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
		gbc_scrollPane_1.gridwidth = 11;
		gbc_scrollPane_1.gridheight = 8;
		gbc_scrollPane_1.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_1.gridx = 5;
		gbc_scrollPane_1.gridy = 0;
		panel_16.add(scrollPane_1, gbc_scrollPane_1);
		
		JTextArea textArea = new JTextArea();
		scrollPane_1.setViewportView(textArea);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		GridBagConstraints gbc_scrollPane_4 = new GridBagConstraints();
		gbc_scrollPane_4.gridwidth = 4;
		gbc_scrollPane_4.gridheight = 8;
		gbc_scrollPane_4.insets = new Insets(0, 0, 0, 5);
		gbc_scrollPane_4.fill = GridBagConstraints.BOTH;
		gbc_scrollPane_4.gridx = 0;
		gbc_scrollPane_4.gridy = 0;
		panel_16.add(scrollPane_4, gbc_scrollPane_4);
		
        JList list_1 = new JList();
		scrollPane_4.setViewportView(list_1);
		
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("�ղظ赥", null, panel_4, null);
		panel_4.setLayout(new GridLayout(1, 0, 0, 0));
		
		JPanel panel_17 = new JPanel();
		panel_4.add(panel_17);
		panel_17.setLayout(new GridLayout(1, 0, 0, 0));
		
		/*�赥��*/
		DefaultMutableTreeNode sum = new DefaultMutableTreeNode("��");
		JTree tree = new JTree(sum);
		panel_17.add(tree);

		JPanel panel_3 = new JPanel();
		GridBagConstraints gbc_panel_3 = new GridBagConstraints();
		gbc_panel_3.fill = GridBagConstraints.HORIZONTAL;
		gbc_panel_3.anchor = GridBagConstraints.SOUTH;
		gbc_panel_3.gridwidth = 7;
		gbc_panel_3.gridx = 0;
		gbc_panel_3.gridy = 6;
		panel.add(panel_3, gbc_panel_3);
		GridBagLayout gbl_panel_3 = new GridBagLayout();
		gbl_panel_3.columnWidths = new int[]{28, 68, 68, 68, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_panel_3.rowHeights = new int[]{27, 0};
		gbl_panel_3.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel_3.rowWeights = new double[]{0.0, Double.MIN_VALUE};
		panel_3.setLayout(gbl_panel_3);
				//    ���Ű�ť������������
				JPanel panel_19 = new JPanel();
				GridBagConstraints gbc_panel_19 = new GridBagConstraints();
				gbc_panel_19.fill = GridBagConstraints.BOTH;
				gbc_panel_19.insets = new Insets(0, 0, 0, 5);
				gbc_panel_19.gridx = 0;
				gbc_panel_19.gridy = 0;
				panel_3.add(panel_19, gbc_panel_19);
				panel_19.setLayout(new GridLayout(1, 0, 0, 0));
						//�����Ĳ��Ű�ť
						JButton btnNewButton = new JButton("last");
						
						GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
						gbc_btnNewButton.fill = GridBagConstraints.BOTH;
						gbc_btnNewButton.insets = new Insets(0, 0, 0, 5);
						gbc_btnNewButton.gridx = 1;
						gbc_btnNewButton.gridy = 0;
						panel_3.add(btnNewButton, gbc_btnNewButton);
				
						JButton btnNewButton_1 = new JButton("p/s");
						
						GridBagConstraints gbc_btnNewButton_1 = new GridBagConstraints();
						gbc_btnNewButton_1.fill = GridBagConstraints.BOTH;
						gbc_btnNewButton_1.insets = new Insets(0, 0, 0, 5);          //    ���֮��ļ��
						gbc_btnNewButton_1.gridx = 2;
						gbc_btnNewButton_1.gridy = 0;
						panel_3.add(btnNewButton_1, gbc_btnNewButton_1);
		
				JButton btnNewButton_2 = new JButton("next");
				
				
				GridBagConstraints gbc_btnNewButton_2 = new GridBagConstraints();
				gbc_btnNewButton_2.insets = new Insets(0, 0, 0, 5);
				gbc_btnNewButton_2.fill = GridBagConstraints.BOTH;
				gbc_btnNewButton_2.gridx = 3;
				gbc_btnNewButton_2.gridy = 0;
				panel_3.add(btnNewButton_2, gbc_btnNewButton_2);
				
				JSlider slider = new JSlider();
				GridBagConstraints gbc_slider = new GridBagConstraints();
				gbc_slider.fill = GridBagConstraints.HORIZONTAL;
				gbc_slider.gridwidth = 11;
				gbc_slider.insets = new Insets(0, 0, 0, 5);
				gbc_slider.gridx = 4;
				gbc_slider.gridy = 0;
				panel_3.add(slider, gbc_slider);
					
				JLabel label_3 = new JLabel("");                    //ѭ��ͼ��         
				label_3.setIcon(new ImageIcon(LocalMusic.class.getResource("/NewMusic/photos/oneRound.png")));
				GridBagConstraints gbc_label_3 = new GridBagConstraints();
				gbc_label_3.insets = new Insets(0, 0, 0, 5);
				gbc_label_3.gridx = 15;
				gbc_label_3.gridy = 0;
				panel_3.add(label_3, gbc_label_3);
				
				JLabel label_2 = new JLabel("\u6536\u85CF");
				GridBagConstraints gbc_label_2 = new GridBagConstraints();
				gbc_label_2.insets = new Insets(0, 0, 0, 5);
				gbc_label_2.gridx = 16;
				gbc_label_2.gridy = 0;
				panel_3.add(label_2, gbc_label_2);
				
				JLabel label_4 = new JLabel("\u97F3\u91CF");
				GridBagConstraints gbc_label_4 = new GridBagConstraints();
				gbc_label_4.insets = new Insets(0, 0, 0, 5);
				gbc_label_4.gridx = 17;
				gbc_label_4.gridy = 0;
				panel_3.add(label_4, gbc_label_4);

		
		/**���Ű�ť��������**/
		
		/*��������*/
		JPanel panel_13 = new JPanel();
		tabbedPane.addTab("�������", null, panel_13, null);
		panel_13.setLayout(new GridLayout(1, 0, 0, 0));
		
		
		JPanel panel_14 = new JPanel();
		panel_13.add(panel_14);
		panel_14.setLayout(new GridLayout(1, 0, 0, 0));
		
		JList list_2 = new JList();
        panel_14.add(list_2);
		
		/*ִ���������򣬷����������*/
		/**������ͼ�����Ӽ�����**/
		lblIcon.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				System.out.println("ִ����������");
				SearchResult search = new SearchResult(textField.getText());
		
					list_2.setListData(search.putResult());               // ����list����
					LocalListListener listlisten_2 = new LocalListListener(list_2);            //��������ͬ�����ţ������
					listlisten_2.listenerOneTime(btnNewButton_1,slider);
					//list_2.removeAll();
					
				tabbedPane.setSelectedIndex(4);                                    //            �л�JTabble��������
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			
		});
		
		/**��LIST���ظ����б��·���Ϊ�˰�Button�������ȥ**/
		/*�����б�*/
		JScrollPane scrollPane = new JScrollPane();
		panel_5.add(scrollPane);
		JList list = new JList(SongName21);
		scrollPane.setViewportView(list);
		LocalListListener listlisten_1 = new LocalListListener(list);              //  ����һ���б���������
		
		System.out.println(listlisten_1.getSongName());
		frame.setVisible(true);
		listlisten_1.listener(btnNewButton,btnNewButton_1,btnNewButton_2,slider,js,lcomdel,lyricList,label_3,tree);//js�û�����,       
		
		/**��ѭ������**/
		new Reset(information, lblNewLabel, lblNewLabel_9, lblNewLabel_8, lblNewLabel_7, list_1, sum,list).start();
		//listlisten_2.listener(btnNewButton,btnNewButton_1,btnNewButton_2,slider,js,lcomdel,lyricList);
		//		playMusic p = new playMusic();//  ����һ�����Ŷ���
		//		p.getConnection();
		
		tree.addTreeSelectionListener(new TreeSelectionListener() {
			
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				// TODO Auto-generated method stub
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
			    if(node.isLeaf()) {
			    	doit.command = 2;
			    	doit.DownName = node.getUserObject().toString();
			    }
			}
		});
		
	}
}
class Reset extends Thread{
	

	private TransferInformation information;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_9;
	//private JTree tree;
	public DefaultMutableTreeNode sum;
	private JList list;
	public Reset(TransferInformation information, JLabel lblNewLabel, JLabel lblNewLabel_9, JLabel lblNewLabel_8,
			JLabel lblNewLabel_7,JList list_1, DefaultMutableTreeNode sum, JList list) {
		super();
		this.information = information;
		this.lblNewLabel = lblNewLabel;
		this.lblNewLabel_9 = lblNewLabel_9;
		this.lblNewLabel_8 = lblNewLabel_8;
		this.lblNewLabel_7 = lblNewLabel_7;
		this.list_1 = list_1;
		this.list = list;
		this.sum = sum;
	}

	private JLabel lblNewLabel_8;
	private JLabel lblNewLabel_7;
	private JList list_1;

	public void run() {
		while(true) {
			try {
				Thread.sleep(4);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if(information.hasChange) {
				lblNewLabel.setText("�˳�");
				lblNewLabel_9.setText(information.name);
				lblNewLabel_8.setIcon(new ImageIcon("C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\����"+"\\" + information.imageName));
				lblNewLabel_7.setText(information.txt);
				System.out.println( "  ������ :" + information.friends[0]);
				Treeupdata();
				list_1.setListData(information.friends);
				if(information.hasListChange) {
				list.setListData(new GetList().getSongstring());
				information.hasListChange = false;
				}
				System.out.println("���ǽ�����µ�ʱ�������");
				information.hasChange=false;
				
			}
		}
	}

	private void Treeupdata() {
		// TODO Auto-generated method stub\
		System.out.println("��ȥ��");
		System.out.println(information.menuNum+ "            �赥����");
		DefaultMutableTreeNode[] menus = new DefaultMutableTreeNode[3];
		for (int i = 0; i < information.menuNum; i++) {
			System.out.println(i);
			menus[i] = new DefaultMutableTreeNode(information.menu.get(i).getMenuName());
			sum.add(menus[i]);                                                                     //����������
			//DefaultMutableTreeNode[] song = new DefaultMutableTreeNode[3];
			/*����Ϊ�Ϲ�֮����Ч�ʲ���*/
			for (int j = 0; j < information.SongsNum; j++) {
				System.out.println("����" + information.songs.get(j).getMenu()+"    gedandemingzi");
				if(information.songs.get(j).getMenu().equals(information.menu.get(i).getMenuName())) {
					System.out.println("����" + "�����ӽڵ�"+information.songs.get(j).getSongs());
					menus[i].add(new DefaultMutableTreeNode(information.songs.get(j).getSongs()));
				}	
			}
		}
		
	}
}