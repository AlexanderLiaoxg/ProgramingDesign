package NewMusic;

import java.io.File;
import java.io.IOException;

import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.NoPlayerException;
import javax.media.Player;
import javax.media.Time;
import javax.media.bean.playerbean.MediaPlayer;

public class playMusic {
	private static MediaPlayer play = new MediaPlayer();
	private String song;
	private String path = "C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\֩�벥������\\";
	public playMusic(String song) {
		super();
		this.song = song;
	}


	public playMusic() {
		super();
	}


	public void getConnection() throws NoPlayerException, IOException {
   
	File musicFile = new File(path + song);
	MediaLocator  locator=new MediaLocator("file:"+musicFile.getAbsolutePath());  
	play.setMediaLocator(locator);
	play.prefetch();// Ԥ���ļ�	

	}

 
 public void start() {
	 play.start();
	 System.out.println("��������");
 }
 public void stop() {
	 play.stop();
	 System.out.println("��ͣ����");
 }
 public void close() {
	 play.close();
	 System.out.println("ֹͣ����");
 }
 public Time getDuration() {
         return play.getDuration();
 }
 public MediaPlayer Player(){
	return play;
	 
 }


public void setMediaTime(Time time) {
	// TODO Auto-generated method stub
	play.setMediaTime(time);
}


public Time getMediaTime() {
	// TODO Auto-generated method stub
	return play.getMediaTime();
}

public MediaPlayer getPlayer() {
	return play;
}
}
