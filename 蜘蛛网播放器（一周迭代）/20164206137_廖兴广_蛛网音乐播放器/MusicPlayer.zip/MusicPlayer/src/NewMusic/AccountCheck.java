package NewMusic;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Part.AccountInformation;
import Part.TransferInformation;

/*
 * ������Ҫ����JDBC�����Ӳ��Ƚ����ݿⷵ�ص��˻����������ݣ���ĳ���������ж�ֵ
 */

public class AccountCheck {

	public JFrame frame;
	private JPasswordField passwordField_1;
	private JTextField textField;
	protected boolean is_close = false;
	private DataOutputStream dos;
	private DataInputStream dis;
	private TransferInformation information;
	private Socket socket;

	public String getPasswords() {
		return String.valueOf(passwordField_1.getPassword());
	}

	public String getAccount() {
		return textField.getText();
	}

	/**
	 * Create the application.
	 * 
	 * @param dis
	 * @param information
	 * @param socket 
	 * @param os
	 */
	public AccountCheck(DataOutputStream dos, DataInputStream dis, TransferInformation information, Socket socket) {
		this.dos = dos;
		this.dis = dis;
		this.information = information;
		this.socket = socket;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 360, 240);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 342, 193);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(151, 97, 63, 27);
		panel.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("\u8D26\u6237\uFF1A");
		lblNewLabel.setBounds(43, 24, 55, 18);
		panel.add(lblNewLabel);

		JLabel label = new JLabel("\u5BC6\u7801\uFF1A");
		label.setBounds(43, 66, 72, 18);
		panel.add(label);

		passwordField_1 = new JPasswordField();
		passwordField_1.setBounds(128, 66, 144, 18);
		panel.add(passwordField_1);

		textField = new JTextField();
		textField.setBounds(128, 24, 144, 18);
		panel.add(textField);
		textField.setColumns(10);

		/** ���Ӷ�������ַ���ܣ����������롱�͡�ע�ᡱ���������� **/
		JLabel label_1 = new JLabel("\u5FD8\u8BB0\u5BC6\u7801\uFF1F");
		label_1.setBounds(43, 140, 83, 18);
		panel.add(label_1);
		label_1.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				label_1.setText("\u5FD8\u8BB0\u5BC6\u7801\uFF1F");
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				label_1.setText("<html><u>\u5FD8\u8BB0\u5BC6\u7801\uFF1F</html></u>");// label֧��html����
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub

			}
		});

		JLabel label_2 = new JLabel("\u6CE8\u518C\u65B0\u8D26\u53F7");
		label_2.setBounds(237, 140, 83, 18);
		label_2.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				label_2.setText("\u6CE8\u518C\u65B0\u8D26\u53F7");

			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				label_2.setText("<html><u>\u6CE8\u518C\u65B0\u8D26\u53F7</html></u>");
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				      /**����ҳ**/
				     File file = new File("ע��.html");
			        Runtime ce=Runtime.getRuntime();
			        System.out.println(file.getAbsolutePath());
			        try {
						ce.exec("cmd   /c   start  "+file.getAbsolutePath());
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			}
		});
		panel.add(label_2);

		frame.setVisible(true);
		/** ����ť���Ӽ����� **/
		btnNewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				try {
					if (getPasswords().equals("") || getAccount().equals("")) {
						JOptionPane.showMessageDialog(null, "�˻������벻��Ϊ�գ�");
					} else {
						dos.writeUTF(1 + " " + getAccount() + " " + getPasswords()); // �ո�����

						is_close = Boolean.parseBoolean(dis.readUTF());
						if (is_close) {
							System.out.println("��֤��ȷ������");
							String baseinformation = dis.readUTF(); // ���ջ�����Ϣ
							information.analyzInformation(baseinformation);
							/**��ø赥**/
							information.menuNum = dis.readInt();
							for(int i=0;i<information.menuNum;i++) {
								String MenuInformation = dis.readUTF();
								information.analyzMenuInformation(MenuInformation);
							}
							/**��ø赥�ĸ�����Ϣ**/
							information.SongsNum = dis.readInt();
							for(int i=0;i<information.SongsNum;i++) {
								String SongsInformation = dis.readUTF();
								information.analyzSongsInformation(SongsInformation);
							}
							/** �õ����� **/
							information.friendsNum = dis.readInt();
							getFriends(dis, information);
							/** ��ȡͼƬ **/
							getFile(dis);
							//JOptionPane.showMessageDialog(null, "���"+information.friends[0]);
							JOptionPane.showMessageDialog(null, "�����ļ��ɹ�");
							information.hasChange = true;
							frame.dispose();// �رմ��ڵ��ǲ��رճ���
						} else {
							JOptionPane.showMessageDialog(null, "�˻������������");
						}
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		/** ���̼��� �ö�Ϊ�ظ����� **/
		/** ���μ�����Ϊ�������������ʱ������ж� **/
		textField.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyChar() == KeyEvent.VK_ENTER) {
					try {
						if (getPasswords().equals("") || getAccount().equals("")) {
							JOptionPane.showMessageDialog(null, "�˻������벻��Ϊ�գ�");
						} else {
							dos.writeUTF(1 + " " + getAccount() + " " + getPasswords()); // �ո�����

							is_close = Boolean.parseBoolean(dis.readUTF());
							if (is_close) {
								System.out.println("��֤��ȷ������");
								String baseinformation = dis.readUTF(); // ���ջ�����Ϣ
								information.analyzInformation(baseinformation);
								/**��ø赥**/
								information.menuNum = dis.readInt();
								for(int i=0;i<information.menuNum;i++) {
									String MenuInformation = dis.readUTF();
									information.analyzMenuInformation(MenuInformation);
								}
								/**��ø赥�ĸ�����Ϣ**/
								information.SongsNum = dis.readInt();
								for(int i=0;i<information.SongsNum;i++) {
									String SongsInformation = dis.readUTF();
									information.analyzSongsInformation(SongsInformation);
								}
								/** �õ����� **/
								information.friendsNum = dis.readInt();
								getFriends(dis, information);
								/** ��ȡͼƬ **/
								getFile(dis);
								JOptionPane.showMessageDialog(null, "���"+information.friends[0]);
								JOptionPane.showMessageDialog(null, "�����ļ��ɹ�");
								information.hasChange = true;
								frame.dispose();// �رմ��ڵ��ǲ��رճ���
							} else {
								JOptionPane.showMessageDialog(null, "�˻������������");
							}
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}
			}
		});

		passwordField_1.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				if (e.getKeyChar() == KeyEvent.VK_ENTER) {
					try {
						if (getPasswords().equals("") || getAccount().equals("")) {
							JOptionPane.showMessageDialog(null, "�˻������벻��Ϊ�գ�");
						} else {
							dos.writeUTF(1 + " " + getAccount() + " " + getPasswords()); // �ո�����

							is_close = Boolean.parseBoolean(dis.readUTF());
							if (is_close) {
								System.out.println("��֤��ȷ������");
								String baseinformation = dis.readUTF(); // ���ջ�����Ϣ
								information.analyzInformation(baseinformation);
								/**��ø赥**/
								information.menuNum = dis.readInt();
								for(int i=0;i<information.menuNum;i++) {
									String MenuInformation = dis.readUTF();
									information.analyzMenuInformation(MenuInformation);
								}
								/**��ø赥�ĸ�����Ϣ**/
								information.SongsNum = dis.readInt();
								for(int i=0;i<information.SongsNum;i++) {
									String SongsInformation = dis.readUTF();
									information.analyzSongsInformation(SongsInformation);
								}
								/** �õ����� **/
								information.friendsNum = dis.readInt();
								getFriends(dis, information);
								/** ��ȡͼƬ **/
								getFile(dis);
								JOptionPane.showMessageDialog(null, "���"+information.friends[0]);
								JOptionPane.showMessageDialog(null, "�����ļ��ɹ�");
								information.hasChange = true;
								frame.dispose();// �رմ��ڵ��ǲ��رճ���
							} else {
								JOptionPane.showMessageDialog(null, "�˻������������");
							}
						}
					} catch (Exception e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				}
			}
		});
	}

	protected void getFriends(DataInputStream dis, TransferInformation information) throws IOException {
		// TODO Auto-generated method stub
		int i = 0;
		information.friends = new String[information.friendsNum];
		while (i<information.friendsNum) {
				String s = dis.readUTF();
				information.friends[i] = s;
				System.out.println(i + "   :" + information.friends[i]);
				i++;
				

		}
	}
	
	protected void getFile(DataInputStream dis) throws IOException {
		// TODO Auto-generated method stub
		File getfile = new File("C:\\Users\\���˹�\\Desktop\\֩������������һ�ܵ�����\\����" + "\\" + information.imageName);
		System.out.println(getfile.toString() + "This is file to create");
		if (getfile.exists()) {

		} else {
			DataOutputStream fos = new DataOutputStream(new FileOutputStream(getfile));
			int hasread;
			byte b[] = new byte[1024];
			while ((hasread = dis.read(b)) != -1) {
				fos.write(b);
			}
			fos.close();
			dis.close();
			socket.close();
			JOptionPane.showMessageDialog(null, "д�����");
		}
		
	}

}
