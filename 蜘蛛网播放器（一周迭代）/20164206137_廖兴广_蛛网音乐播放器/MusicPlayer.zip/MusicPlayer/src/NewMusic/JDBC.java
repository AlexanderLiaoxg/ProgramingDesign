package NewMusic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import Part.AccountInformation;

public class JDBC {
	private static DBOperation d = null;
	private String Account;
	private String password;

	public JDBC(String Account, String Password) throws Exception {
		super();
		this.Account = Account;
		this.password = Password;
	}

	public boolean createConnection() throws Exception {
		// String Driver="org.mm.mysql.Driver";
		Boolean ap_is_right; // ��֤�˻������Ƿ���ȷ����ȷ��ر���֤����
		String Driver = "com.mysql.jdbc.Driver";
		String Url = "jdbc:mysql://localhost:3306/MAI";
		String User = "root";
		String Password = "123456";
		Connection con = null;

		Class.forName(Driver);// ��̬����Mysql����
		con = DriverManager.getConnection(Url, User, Password);
		System.out.println("connect sucess!");
		java.sql.Statement stmt = con.createStatement();
		d = new DBOperation(con, Account, password);
		ap_is_right = d.selectAlldata(con);
		d.selectFriendsState(con);
		d.selectFriends(con);
		d.selectSongmenu(con);
		d.selectSongs(con);
		return ap_is_right;

	}

	// �����getd��getainformationȫ��Ϊ�˴�����Ϣ
	public DBOperation getd() {
		return d;

	}

	public String getAccountInformation() {
		// TODO Auto-generated method stub
		return d.getAccountInformation();
	}

	public String getIma() {
		return d.getIma();
	}

	public String[] getFriends() {
		return d.getFriends();
	}

	public int getFriendsNum() {
		return d.getFriendsNum();
	}
	
	public String[] getMenuInformation() {
		return d.getMenuInformation();
	}
	
	public int getmenuNum() {
		return d.getmenuNum();
	}
	
	public String[] getSongsInformation() {
		return d.getSongsinformation();
	}
	
	public int getSongsInformationNum() {
		return d.getSongsInformationNum();
	}

}

class DBOperation {
	Connection con;
	private Boolean has_data = false;
	private String Account;
	private String Password;
	private String accountInformation;
	private String ima;
	private String[] Tfriends = new String[100];
	private String[] friends;
	private int friendsNum;
	private String[] TMenuInformation = new String[100];
	private String[] MenuInformation;
	private int menuNum;
	private String[] TSongsInformation = new String[100];
	private String[] SongsInformation;
	private int SongsInformationNum;
	
	public String[] getMenuInformation() {
		return MenuInformation;
	}

	public int getmenuNum() {
		return menuNum;
	}	

	public int getFriendsNum() {
		return friendsNum;
	}

	public String getAccountInformation() {
		return accountInformation;
	}

	public String getIma() {
		return ima;
	}

	public String[] getFriends() {
		return friends;
	}

	public String[] getSongsinformation() {
		return SongsInformation;
	}
	
	public int getSongsInformationNum() {
		return SongsInformationNum;
	}
	
	public DBOperation(Connection con, String Account, String Password) {
		super();
		this.con = con;
		this.Account = Account;
		this.Password = Password; // ת��P��p

	}

	public Boolean selectAlldata(Connection con) {
		// String sql = "select * from student2";
		// String sql = "select sno,sname from student2 where sname = '����'";
		// String sql = "select sno,sname,avg(grade) from student2 where sname = '������'";
		// String sql = "select * from student2 where sex = '��'";
		String sql = "select * from AP";
		System.out.println("�����˻���" + Account + "\n�������룺" + Password + "\n");
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql); // ִ��sql����Ľ����
			while (rs.next()) {
				String Daccount = rs.getString("account");
				String Dpassword = rs.getString("password");
				String name = rs.getString("name");
				ima = rs.getString("image"); // Ҫ���ļ��ĸ�ʽ����
				String txt = rs.getString("txt");
				String imageName = rs.getString("imageName");
				if (Account.equals(Daccount) && Password.equals(Dpassword)) {
					has_data = true; // ��֤��Ϣ��ȷ
					accountInformation = Daccount + " " + Dpassword + " " + name + " " + imageName + " " + txt; // �����û���Ϣ
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("�˻������������");
		return false;
	}

	public void selectFriends(Connection con) {
		String sql = "select * from friends";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql); // ִ��sql����Ľ����
			int i = 0;
			while (rs.next()) {
				String account = rs.getString("account");
				if(account.equals(Account)) {
				String friendsAccount = rs.getString("friend_account");
				System.out.println(account + "�ĺ��ѣ�" + friendsAccount);
				if (account.equals(Account)) {
					Tfriends[i] = friendsAccount;
					i++;
				}
				}
			}
			friends = new String[i];
			for (int j = 0; j < i; j++) {
				friends[j] = Tfriends[j];
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectFriendsState(Connection con) {
		String sql = "select * from friendsstate";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql); // ִ��sql����Ľ����
			while (rs.next()) {
				String account = rs.getString("account");
				if(account.equals(Account)) {
				String state = rs.getString("state");
				int friendsnum = rs.getInt("friendsNum");
				friendsNum = friendsnum;
				System.out.println("JDBC" + account + "�ĺ���num��" + friendsNum);
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectSongmenu(Connection con) {
		String sql = "select * from songmenu";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql); // ִ��sql����Ľ����
			int i = 0;
			while (rs.next()) {
				String account = rs.getString("account");
				if(account.equals(Account)) {
				String songmenuName = rs.getString("songMenuName");
				int songsnum = rs.getInt("songsNum");
				TMenuInformation[i] = songmenuName + " " + songsnum;
				i++;
				System.out.println(account + "�ĸ���num��" + songmenuName + " num" + songsnum);
			}
			}
			menuNum = i;                                   //          ͨ���������ݿ�ĸ赥�������洢�赥����
			MenuInformation = new String[i];
			for (int j = 0; j < i; j++) {
				MenuInformation[j] = TMenuInformation[j];
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/*�о������songsnum���ã��˴��ṩ�ڶ��ַ�������ά����洢*/
	public void selectSongs(Connection con) {
		String sql = "select * from songs";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql); // ִ��sql����Ľ����
			int i = 0;
			while (rs.next()) {
				String account = rs.getString("account");
				if(account.equals(Account)) {
				String songmenuName = rs.getString("songmenu");
				String songName = rs.getString("songName");
				TSongsInformation[i] = songmenuName + " " + songName;
				i++;
				System.out.println(account + "�ĸ赥��" + songmenuName + " �ĸ���" + songName);
			}
			}
			SongsInformationNum = i;                                   //          ͨ���������ݿ�ĸ赥�������洢�赥����
			SongsInformation = new String[i];
			for (int j = 0; j < i; j++) {
				SongsInformation[j] = TSongsInformation[j];
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
