function forgetPassword(){
	alert("功能尚未开通请联系开发者:LXG : 1285984525@qq.com");
}
